def aggiorna(valore,lista,fatore=2):
    valore=valore*fattore
    lista.append(valore)
    return valore
x=3
dati=[1,2]
ris1=aggiorna(x,dati)
res2=aggiorna(x,dati,3)