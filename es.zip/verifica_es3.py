def modifica_numero (n):
    n=n+10
    
def modifica_lista (lista):
    lista.append(10)
    
n=5
numeri=[1,2,3]
modifica_numero(x)
modifica_lista(numeri)