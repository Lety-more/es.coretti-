#quaeta e una procedura
def stampa_quadratto(n):
    print(n*n)
  
#quaesta e una funzione   
def calcola_quadrtro(n):
    return(n*n)

stampa_quadratto(7)
numero=calcola_quadrtro(5)