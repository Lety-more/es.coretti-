# codice 1
x=10
if x > 5:
    print("maggiore di 5")

# codice 2
a=5
b=10
somma=a+b
print(somma)

# codice 3
x=0
for i in range(0,5):
    if i % 2 == 0:
        x += 1
print(x)

# codice 4
numero=10
if numero > 5:
    print("il numero e maggiore di 5")
else:
    print("il numero e minore di 5")
if numero < 15:
    print("numero e piccolo")

# codice 6
nome="alice" 
eta=25
print("ciao, " + nome + " hai "+ str(eta) + " anni" )

# codice 7
frutti=["mela", "banana","ciliega","pera"]
frutti.remove("pera")
print(frutti)

# codice 8
lista=[10, 20, 30]
print(lista[2])

# codice 9
for i  in range(5):
    print(i)
    if i == 3:
        break
        print("questo non drovebbe apparire")

# 