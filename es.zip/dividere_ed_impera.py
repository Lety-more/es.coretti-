#scrvere una funzioni che data 2 numeri interi che restituisca il maggiore

def maggiore (num1,num2):
    if num1>num2:
        return num1
    else:
        return num2
"""
uno=input("inserire il primo numero")
uno=int(uno)
due=input("inserire il secondo numero")
due=int(due)

risultato=maggiore(uno,due)
print(risultato)
"""
#scrvivere una procedura che dato un numero intero  stanpi a video se e pari o dispari
def paridisp(num):
    if num%2==0:
        print("PARI")
    else:
        print("DISPARI")

uno=input("inserire il primo numero")
uno=int(uno)
due=input("inserire il secondo numero")
due=int(due)

risultato=maggiore(uno,due)
print(risultato)
paridisp(risultato)

#ho fatto un programma diviso ma e una sola cosa srivere un programma che dati 2 intri che stampi a video se il maggiore e pari dispari
